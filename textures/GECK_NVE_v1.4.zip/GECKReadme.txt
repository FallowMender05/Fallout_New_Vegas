*****************************************************************

     The Garden of Eden Creation Kit (New Vegas Edition)
			      1.4
        	 
*****************************************************************



Index:
1. General Issues
2. System Requirements


*****************************************************************

     1. General Issues

*****************************************************************

The Garden of Eden Creation Kit (GECK) allows you to edit and create content
for Fallout: New Vegas.

Fallout: New Vegas is required to create and play content created with
The Garden of Eden Creation Kit. 

The New Vegas Edition of GECK is not compatible with Fallout 3.

It is strongly recommended that you have at least 2 GB of RAM to use
the Heightmap Editing feature, and for any world and level building.

Limited user accounts will not be able to use the GECK. You must
have administrative rights.

The GECK will occasionally appear to hang or lock up while
attempting to exit. Wait 5 minutes. If it still hasn't closed, press
CTRL-ALT-DEL and manually END TASK on the application.

Visit http://geck.bethsoft.com for the latest documentation and tutorials, and our 
official forums at http://www.bethsoft.com/bgsforums/.


*****************************************************************

     2. System Requirements

*****************************************************************

-Minimum System Requirements:
* Windows XP/Vista
* 1GB System RAM (XP)/ 2GB System RAM (Vista)
* 2.4 Ghz Intel Pentium 4 or equivalent processor
* Direct X 9.0c compliant video card with 256MB RAM (NVIDIA 6800 or better/ATI X850 or better)

-Recommended System Requirements:
* Intel Core 2 Duo processor
* 2 GB System RAM
* Direct X 9.0c compliant video card with 512MB RAM

-Supported Video Card Chipsets:
ATI HD 4800 series
ATI HD 4600 series
ATI HD 3800 series
ATI HD 3600 series
ATI HD 3400 series
ATI HD 2900 series
ATI HD 2600 series
ATI HD 2400 series
ATI X1900 series
ATI X1800 series
ATI X1600 series
ATI X1300 series
ATI X850 series

NVIDIA GeForce 200 series
NVIDIA Geforce 9800 series
NVIDIA Geforce 9600 series
NVIDIA Geforce 8800 series
NVIDIA Geforce 8600 series
NVIDIA Geforce 8500 series
NVIDIA Geforce 8400 series
NVIDIA Geforce 7900 series
NVIDIA Geforce 7800 series
NVIDIA Geforce 7600 series
NVIDIA Geforce 7300 series
NVIDIA GeForce 6800 series


VIDEO
-Regardless of your video card, make sure to download the latest drivers from your manufacturer.



